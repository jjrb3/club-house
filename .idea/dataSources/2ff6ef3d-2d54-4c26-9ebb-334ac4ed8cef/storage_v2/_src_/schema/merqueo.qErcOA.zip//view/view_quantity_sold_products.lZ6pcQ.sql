create definer = root@localhost view view_quantity_sold_products as
select `i`.`id`             AS `id`,
       `o`.`delivery_date`  AS `delivery_date`,
       `i`.`product_name`   AS `product_name`,
       sum(`qp`.`quantity`) AS `quantity`
from ((`merqueo`.`inventories` `i` join `merqueo`.`quantity_products` `qp` on ((`qp`.`inventory_id` = `i`.`id`)))
         join `merqueo`.`orders` `o` on ((`qp`.`order_id` = `o`.`id`)))
group by `i`.`id`, `o`.`delivery_date`, `i`.`product_name`
order by `o`.`delivery_date` desc;

